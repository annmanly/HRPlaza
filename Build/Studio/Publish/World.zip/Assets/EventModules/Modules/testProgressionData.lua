--!Type(Module)
testTiers = {
    {
        tier = 1,
        item_id = "sock-n_winterwear2024set3blackfuzzysocks",
        cost = 500,
        amount = 1,
        category = "avatar_item",
        _id = "675079a7d5b88c3618a71f06"
    },
    {
        tier = 2,
        item_id = "gloves-n_winterwear2024set3gloves",
        cost = 5850,
        amount = 1,
        category = "avatar_item",
        _id = "675079a7d5b88c3618a71f1a"
    },
    {
        tier = 3,
        item_id = "pants-n_winterwear2024set3joggers",
        cost = 16350,
        amount = 1,
        category = "avatar_item",
        _id = "675079a7d5b88c3618a71f30"
    },
    {
        tier = 4,
        item_id = "shirt-n_winterweargrabtwo2024silverjacket",
        cost = 30850,
        amount = 1,
        category = "avatar_item",
        _id = "675079a7d5b88c3618a71f44"
    },
    {
        tier = 5,
        item_id = "hat-n_winterwear2024set3whitepuffybeanie",
        cost = 69850,
        amount = 1,
        category = "avatar_item",
        _id = "675079a7d5b88c3618a71f6e"
    },
    {
        tier = 6,
        item_id = "necklace-n_winterwear2024set3plaidscarf",
        cost = 49850,
        amount = 1,
        category = "avatar_item",
        _id = "675079a7d5b88c3618a71f5a"
    },
    {
        tier = 7,
        item_id = "shirt-n_winterwearstaff202401furjacket",
        cost = 649850,
        amount = 1,
        category = "avatar_item",
        _id = "675079a7d5b88c3618a71fb6"
    },
    {
        tier = 8,
        item_id = "shirt-n_winterwearstaff202401furtop",
        cost = 2964850,
        amount = 1,
        category = "avatar_item",
        _id = "675079a7d5b88c3618a71fc4"
    }
}