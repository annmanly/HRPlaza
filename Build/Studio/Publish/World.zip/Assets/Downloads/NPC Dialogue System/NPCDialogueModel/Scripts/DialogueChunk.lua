--!Type(ScriptableObject)

--!SerializeField
local Pages: {DialoguePage} = {}

function GetPages()
    return Pages
end