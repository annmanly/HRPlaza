--!Type(UI)

--!Bind
local _title:UILabel = nil

--!Bind
local _wishAuthor:UILabel = nil
--!Bind
local _wishContent:UILabel = nil
--!Bind
local _wishDate:UILabel = nil


_title:SetPrelocalizedText("Wishing Fountain")
_wishAuthor:SetPrelocalizedText("Test Name")
_wishContent:SetPrelocalizedText("I wish for sushi!")
_wishDate:SetPrelocalizedText("08-25-2025")