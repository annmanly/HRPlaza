-- A Network Integer to keep track of weather or not it is X's or O's turn next
Turn = IntValue.new("Turn", 0)