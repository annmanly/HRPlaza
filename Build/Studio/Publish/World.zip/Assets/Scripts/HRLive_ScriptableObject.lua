--!Type(ScriptableObject)

--!SerializeField
local eventImages: {Texture} = {}

function GetEventImages() : {Texture}
    return eventImages
end

